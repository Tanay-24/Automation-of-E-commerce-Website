package Ekart.Ekart;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.*;

import io.cucumber.java.en.*;
public class Verify_title_and_other {
	
	WebDriver driver;
	@BeforeTest
    @Given("User launches the browser and opens the Automation Exercise site")
    public void launchBrowser() {
    	System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }
	
	@Test(priority=1)
    @When("User clicks on the {string} button of the first product")
    public void clickViewProduct(String buttonText) throws InterruptedException, IOException {
		driver.get("https://automationexercise.com/");
    	driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
    	WebElement viewProductButton = driver.findElement(By.xpath("(//a[contains(text(),'" + buttonText + "')])[1]"));
        viewProductButton.click();
        Thread.sleep(3000);
	    File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
		File dest = new File(destPath);
		FileHandler.copy(src, dest);
		System.out.println("Screenshot saved to: " + dest.getAbsolutePath());
    }
	
	@Test(priority=2)
    @Then("Product title should be visible")
    public void verifyProductTitle() throws InterruptedException {
        WebElement title = driver.findElement(By.xpath("//div[@class='product-information']//h2"));
        Thread.sleep(2000);
        assertTrue("Product title is not visible", title.isDisplayed());
    }

	@Test(priority=3)
	@Then("Product price should be visible")
    public void verifyProductPrice() throws InterruptedException {
        WebElement price = driver.findElement(By.xpath("//div[@class='product-information']//span/span"));
        Thread.sleep(2000);
        assertTrue("Product price is not visible", price.isDisplayed());
    }
	
	@Test(priority=4)
	@Then("Product description should be visible")
    public void verifyProductDescription() {
        WebElement description = driver.findElement(By.xpath("//div[@class='product-information']//p"));
        assertTrue("Product description is not visible", description.isDisplayed());
        driver.quit();
    }
}
