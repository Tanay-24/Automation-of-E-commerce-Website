package Ekart.Ekart;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Automate_Checkout_and_Order_Confirmation {
	WebDriver driver;
    WebDriverWait wait;

    @BeforeTest
    @Given("I am on the checkout page")
    public void i_am_on_checkout_page() {
    	 System.setProperty("webdriver.edge.driver",
                 "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
         driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com");

        driver.findElement(By.linkText("Cart")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Proceed To Checkout"))).click();

        // If not logged in, skip or mock login
        try {
            driver.findElement(By.name("message")).sendKeys("Test order comment");
            driver.findElement(By.xpath("//a[text()='Place Order']")).click();
        } catch (NoSuchElementException ignored) {}
    }

    @Test(priority=1)
    @When("I fill in the billing details with dummy data")
    public void fill_billing_details() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("name_on_card")));
        driver.findElement(By.name("name_on_card")).sendKeys("John Doe");
        driver.findElement(By.name("card_number")).sendKeys("4111111111111111");
        driver.findElement(By.name("cvc")).sendKeys("123");
        driver.findElement(By.name("expiry_month")).sendKeys("12");
        driver.findElement(By.name("expiry_year")).sendKeys("2025");
    }

    @Test(priority=2)
    @And("I validate email and phone field formats")
    public void validate_formats() {
        WebElement emailField = driver.findElement(By.name("email"));
        WebElement phoneField = driver.findElement(By.name("phone"));

        String email = emailField.getAttribute("value");
        String phone = phoneField.getAttribute("value");

        Assert.assertTrue(email.matches("^\\S+@\\S+\\.\\S+$"), "Invalid email format");
        Assert.assertTrue(phone.matches("^[0-9]{10,15}$"), "Invalid phone number");
    }

    @Test(priority=3)
    @And("I click on \"Place Order\"")
    public void click_place_order() {
        driver.findElement(By.id("submit")).click();  // Assuming 'submit' is the button ID
    }

    @Test(priority=4)
    @Then("I should see the order confirmation message")
    public void confirm_order_message() {
        WebElement confirmMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Your order has been placed successfully!')]")));
        Assert.assertTrue(confirmMsg.isDisplayed(), "Confirmation message missing");
    }

    @Test(priority=5)
    @And("I take a screenshot named {string}")
    public void screenshot_confirmation(String name) {
        try {
        	File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
            File dest = new File(destPath);
            FileHandler.copy(src, dest);
            System.out.println("Screenshot saved to: " + dest.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(priority=6)
    @And("I should be redirected to the \"Thank You\" page")
    public void verify_redirection() {
        wait.until(ExpectedConditions.urlContains("order"));
        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains("order") || url.contains("thank-you"), "Not redirected to Thank You page");
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
