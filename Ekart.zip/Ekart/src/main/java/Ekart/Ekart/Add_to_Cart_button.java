package Ekart.Ekart;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Test;

import io.cucumber.java.en.*;

public class Add_to_Cart_button {

	WebDriver driver;

	@Test(priority=1)
    @Given("User launches the browser1 and opens the Automation Exercise site")
    public void user_launches_browser() {
    	 System.setProperty("webdriver.edge.driver",
                 "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
         driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com/");
    }
	@Test(priority=2)
    @When("User clicks on the {string} button1 of the first product")
    public void user_clicks_on_view_product(String buttonText) {
        WebElement viewProduct = driver.findElement(By.xpath("(//a[contains(text(),'" + buttonText + "')])[1]"));
        viewProduct.click();
    }
	@Test(priority=3)
    @And("User clicks on the {string} button")
    public void user_clicks_on_add_to_cart(String buttonText) {
        WebElement addToCartButton = driver.findElement(By.xpath("//button[contains(text(),'" + buttonText + "')]"));
        addToCartButton.click();
    }
	@Test(priority=4)
    @Then("A success message or cart modal should be displayed")
    public void verify_cart_modal_and_take_screenshot() throws IOException {
        try {
            Thread.sleep(2000); // Ideally replaced with WebDriverWait
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement modal = driver.findElement(By.id("cartModal"));
        assertTrue("Cart modal not displayed", modal.isDisplayed());

        // 🖼️ Take Screenshot
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
        File dest = new File(destPath);
        FileHandler.copy(src, dest);
        System.out.println("Screenshot saved to: " + dest.getAbsolutePath());

        driver.quit();
    }
}
