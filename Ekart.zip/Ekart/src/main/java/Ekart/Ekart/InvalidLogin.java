package Ekart.Ekart;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.*;
import io.cucumber.java.en.*;


public class InvalidLogin {
	WebDriver driver;
	@BeforeTest
    public void Sample() {
        System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
    }

	@Test(priority=1)
	@Given("Open automationexercise website")
	public void open_automationexercise_website() {
		 driver.get("https://automationexercise.com/login");
	        driver.manage().window().maximize();
	}
	@Test(priority=2)
	@When("Enter invalid uname1 and pass1")
	public void enter_invalid_uname1_and_pass1() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[2]")).sendKeys("Tanay@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[3]")).sendKeys("wap09370");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/button")).click();
		Thread.sleep(5000);
	}
	@Test(priority=3)
	@Then("Check the error message display or NOT")
	public void check_the_error_message_display_or_not() throws IOException {
		assertEquals("Your email or password is incorrect!","Your email or password is incorrect!");
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
		File dest = new File(destPath);
		FileHandler.copy(src, dest);
		System.out.println("Screenshot saved to: " + dest.getAbsolutePath());
	}
	@AfterTest
	public void end() {
		driver.close();
	}
}
