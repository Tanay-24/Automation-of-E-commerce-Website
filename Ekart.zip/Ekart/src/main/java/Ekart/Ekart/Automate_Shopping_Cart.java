package Ekart.Ekart;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
public class Automate_Shopping_Cart {
	WebDriver driver;
    WebDriverWait wait;

    double subtotal = 0;
    double tax = 0;
    double total = 0;

    @BeforeTest
    @Given("I am on the Automation Exercise home page")
    public void i_am_on_home_page() {
    	System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com");
        Assert.assertTrue(driver.getTitle().contains("Automation Exercise"));
    }

    @Test(priority=1)
    @When("I add {int} units of product with name {string} to the cart")
    public void i_add_units_of_product_to_cart(int qty, String productName) {
        driver.findElement(By.linkText("Products")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".features_items")));

        for (int i = 0; i < qty; i++) {
            WebElement productCard = driver.findElement(By.xpath("//p[contains(text(),'" + productName + "')]/ancestor::div[contains(@class,'productinfo')]"));
            Actions actions = new Actions(driver);
            actions.moveToElement(productCard).perform();

            WebElement addToCartBtn = driver.findElement(By.xpath("//p[contains(text(),'" + productName + "')]/following::a[contains(text(),'Add to cart')]"));
            addToCartBtn.click();
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Continue Shopping')]"))).click();
        }
    }

    @Test(priority=2)
    @Then("I should see {int} distinct items in the cart")
    public void i_should_see_distinct_items(int expectedCount) {
        driver.findElement(By.linkText("Cart")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".cart_info")));
        List<WebElement> cartRows = driver.findElements(By.cssSelector(".cart_info tbody tr"));
        Assert.assertEquals(cartRows.size(), expectedCount, "Cart should have " + expectedCount + " distinct items");
    }
    
    @Test(priority=3)
    @Then("subtotal, tax, and total should be correctly calculated")
    public void subtotal_tax_total_calculation() {
        subtotal = extractAmount("#cart_info_table td.cart_total span");
        tax = subtotal * 0.02; // assume 2% tax (as site doesn’t display tax directly)
        total = subtotal + tax;

        Assert.assertTrue(total > subtotal);
    }

    @Test(priority=4)
    @Then("I take a screenshot1 named {string}")
    public void take_screenshot(String name) {
        try {
        	File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
    		String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
    		File dest = new File(destPath);
    		FileHandler.copy(src, dest);
    		System.out.println("Screenshot saved to: " + dest.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(priority=5)
    @When("I update quantity of product {string} to {int}")
    public void update_quantity(String productName, int quantity) {
        driver.findElement(By.linkText("Cart")).click();
        WebElement qtyInput = driver.findElement(By.xpath("//td[@class='cart_description']//a[contains(text(),'" + productName + "')]/../../following-sibling::td//input[@type='number']"));
        qtyInput.clear();
        qtyInput.sendKeys(String.valueOf(quantity));
        qtyInput.sendKeys(Keys.ENTER);
    }

    @Test(priority=6)
    @Then("that product quantity should be {int}")
    public void verify_product_quantity(int expectedQty) {
        WebElement qtyInput = driver.findElement(By.cssSelector("input.cart_quantity_input"));
        int actualQty = Integer.parseInt(qtyInput.getAttribute("value"));
        Assert.assertEquals(actualQty, expectedQty, "Product quantity mismatch");
    }

    @Test(priority=7)
    @When("I remove product {string} from the cart")
    public void remove_product(String productName) {
        WebElement deleteBtn = driver.findElement(By.xpath("//td[@class='cart_description']//a[contains(text(),'" + productName + "')]/../../following-sibling::td[@class='cart_delete']//a"));
        deleteBtn.click();
    }

    @Test(priority=8)
    @Then("the cart total should reflect the removal")
    public void verify_cart_total_after_removal() {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".cart_info .cart_delete")));
        double newSubtotal = extractAmount("#cart_info_table td.cart_total span");
        Assert.assertTrue(newSubtotal < subtotal, "Subtotal should decrease after removal");
    }

    @Test(priority=9)
    @When("I empty the cart")
    public void empty_cart() {
        List<WebElement> deleteButtons = driver.findElements(By.cssSelector(".cart_delete a"));
        for (WebElement btn : deleteButtons) {
            btn.click();
            wait.until(ExpectedConditions.stalenessOf(btn));
        }
    }

    @Test(priority=10)
    @Then("I should see an empty cart message")
    public void verify_empty_cart_message() {
        Assert.assertTrue(driver.getPageSource().contains("Cart is empty"), "Empty cart message should appear");
    }

    @Test(priority=11)
    @Then("subtotal, tax, and total should all be {string}")
    public void verify_zero_totals(String zero) {
        double currentSubtotal = extractAmount("#cart_info_table td.cart_total span");
        Assert.assertEquals(currentSubtotal, 0.0, "Subtotal should be 0 after emptying cart");
    }

    private double extractAmount(String selector) {
        try {
            List<WebElement> prices = driver.findElements(By.cssSelector(selector));
            double sum = 0;
            for (WebElement price : prices) {
                sum += Double.parseDouble(price.getText().replaceAll("[^\\d.]", ""));
            }
            return sum;
        } catch (Exception e) {
            return 0;
        }
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}