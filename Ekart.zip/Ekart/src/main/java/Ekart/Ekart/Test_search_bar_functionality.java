package Ekart.Ekart;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.*;

import io.cucumber.java.en.*;

public class Test_search_bar_functionality {

	WebDriver driver;
	@BeforeTest
    public void Sample() {
        System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
    }
	@Test(priority=1)
	@Given("Open Website")
	public void open_website() {
		driver.get("https://automationexercise.com/login");
        driver.manage().window().maximize();
	}
	@Test(priority=2)
	@When("Login")
	public void login() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[2]")).sendKeys("wap09370@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[3]")).sendKeys("wap09370");
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Login")).click();
	}
	@Test(priority=3)
	@And("After that click on product")
	public void after_that_click_on_product() {
	    driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
	}
	@Test(priority=4)
	@Then("test search bar with valid and invalid")
	public void test_search_bar_with_valid_and_invalid() throws InterruptedException, IOException {
	    driver.findElement(By.id("search_product")).sendKeys("shirt");
	    driver.findElement(By.xpath("//*[@id=\"submit_search\"]")).click();
	    Thread.sleep(3000);
	    File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String destPath = "D:\\software testing\\Automation of E-commerce Website - MyKart\\Screenshort\\screenshot_" + timestamp + ".png";
		File dest = new File(destPath);
		FileHandler.copy(src, dest);
		System.out.println("Screenshot saved to: " + dest.getAbsolutePath());
	    driver.close();
	}
}
