package Ekart.Ekart;

import io.cucumber.java.en.*;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
public class Automate_category_filter {
	WebDriver driver;

	@BeforeTest
    @Given("User launches the browser and open the Automation Exercise site")
    public void launchBrowserAndOpenSite() {
    	System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com/");
    }
	@Test(priority=1)
    @When("User clicks on the {string} category")
    public void clickOnCategory(String category) throws InterruptedException {
		 driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
        Thread.sleep(2000);
    }
	@Test(priority=2)
    @And("User selects the {string} subcategory")
    public void selectSubCategory(String subcategory) throws InterruptedException {
        WebElement subcategoryElement = driver.findElement(By.xpath("//div[@class='panel-group category-products']//a[contains(text(),'" + subcategory + "')]"));
        subcategoryElement.click();
        Thread.sleep(2000);
    }
	
	@Test(priority=3)
    @Then("Products under {string} category should be displayed")
    public void verifyProductsDisplayed(String expectedCategory) {
        WebElement categoryTitle = driver.findElement(By.xpath("//h2[@class='title text-center']"));
        assertTrue(categoryTitle.getText().toLowerCase().contains(expectedCategory.toLowerCase()));
    }
	
	@AfterTest
	public void close() {
		driver.close();
	}
}
