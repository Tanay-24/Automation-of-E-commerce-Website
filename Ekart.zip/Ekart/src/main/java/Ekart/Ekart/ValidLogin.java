package Ekart.Ekart;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;

import io.cucumber.java.en.*;

public class ValidLogin {
	
	WebDriver driver;
	@BeforeTest
    public void Sample() {
        System.setProperty("webdriver.edge.driver",
                "D:\\software testing\\Automation of E-commerce Website - MyKart\\Ekart\\Drivers\\msedgedriver_138V.exe");
        driver = new EdgeDriver();
    }
	@Test(priority=1)
	@Given("Open automationexercise")
	public void open_automationexercise() {
        driver.get("https://automationexercise.com/login");
        driver.manage().window().maximize();
	}
	@Test(priority=2)
	@When("new user signup")
	public void new_user_signup() throws InterruptedException {
	    driver.findElement(By.name("name")).sendKeys("Wap7");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")).sendKeys("wap09370@gmail.com");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("password")).sendKeys("wap09370");
	    Thread.sleep(2000);
	    driver.findElement(By.id("first_name")).sendKeys("wap");
	    Thread.sleep(2000);
	    driver.findElement(By.id("last_name")).sendKeys("09370");
	    Thread.sleep(2000);
	    driver.findElement(By.id("address1")).sendKeys("Hello9WallStreet");
	    Thread.sleep(2000);
	    driver.findElement(By.id("state")).sendKeys("MH");
	    Thread.sleep(2000);
	    driver.findElement(By.id("city")).sendKeys("KASARA");
	    Thread.sleep(2000);
	    driver.findElement(By.id("zipcode")).sendKeys("210022");
	    Thread.sleep(2000);
	    driver.findElement(By.id("mobile_number")).sendKeys("01234567890");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button")).click();
	}
	
	@Test
	@Then("Again signin using same uname and pass")
	public void again_signin_using_same_uname_and_pass() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[2]")).sendKeys("wap09370@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[3]")).sendKeys("wap09370");
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Login")).click();
	}
}
